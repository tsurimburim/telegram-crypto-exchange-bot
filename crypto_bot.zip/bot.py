# Entry point for the bot
print('Bot started')