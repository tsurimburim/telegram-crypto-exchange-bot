# CryptoBot Setup Guide

1. Install requirements
2. Configure config.py
3. Run `python bot.py`